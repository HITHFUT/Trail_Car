/*
 * HCSR04.h
 *
 *  Created on: 2024��10��24��
 *      Author: LS
 */
#include "zf_common_headfile.h"

#ifndef HCSR04_H_
#define HCSR04_H_

float HCSR04_GetLenght(void);
void Time_On(void);
void Time_Off(void);
float Time_Get_Counter(void);

#endif /* HCSR04_H_ */
