/*
 * PID.c
 *
 *  Created on: 2024��10��31��
 *      Author: LS
 */
#include "zf_common_headfile.h"

pid_param_t PID_IMU;

float constrain_float(float amt, float low, float high)
{
    return ((amt)<(low)?(low):((amt)>(high)?(high):(amt)));
}

float PidLocCtrl(pid_param_t * pid, float error)
{

    PID_IMU.kp=1;//1.15
    PID_IMU.kd=7;

    /* �ۻ���� */
    pid->integrator += error;

    /* ����޷� */
    constrain_float(pid->integrator, -pid->imax, pid->imax);


    pid->out_p = pid->kp * error;
    pid->out_i = pid->ki * pid->integrator;
    pid->out_d = pid->kd * (error - pid->last_error);

    pid->last_error = error;

    pid->out = pid->out_p + pid->out_i + pid->out_d;

    return pid->out;

}

