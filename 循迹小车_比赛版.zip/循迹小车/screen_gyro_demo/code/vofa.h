

#ifndef VOFA_H_
#define VOFA_H_

#include "zf_common_headfile.h"

#define VOFA_UART_INDEX            (UART_7)                 // ָ�� VOFA ��ʹ�õĵĴ���      UART_3
#define VOFA_UART_BAUDRATE         (115200)
#define VOFA_UART_TX_PIN           (UART7_MAP3_TX_E12)      // ָ�� VOFA ��ʹ�õĵĴ�������   UART3_TX_B10
#define VOFA_UART_RX_PIN           (UART7_MAP3_RX_E13)      // ָ�� VOFA ��ʹ�õĵĴ�������     UART3_RX_B11

#define VOFA_UART_PRIORITY         UART7_IRQn //USART1_IRQn



typedef union
{
    float floatData;
    unsigned char byteData[4];
}FLOAT_BYTE;

typedef struct
{
//    uint16_t     biaozhi_F;
//    uint16_t     biaozhi_B;
//    uint16_t     biaozhi_L;
//    uint16_t     biaozhi_R;
//    uint16_t     biaozhi_S;
    u8     biaozhi_F;
    u8     biaozhi_B;
    u8     biaozhi_L;
    u8     biaozhi_R;
    u8     biaozhi_S;
    u8     biaozhi_2;
    u8     forword;
    u8     turn;
    float  p;
    float  i;
    float  d;

    float  A;
    float  B;
    float  C;
    float  D;
    float  E;


}MY_VOFA;
extern MY_VOFA my_dat;
void VOFA_INIT( void );
void VOFA_write_byte( const uint8 dat );
void VOFA_write_float( float dat );
void VOFA_write_int( int dat );
void Just_end( void );
void VOFA_rx_interrupt_handler (void);


#endif /* VOFA_H_ */
