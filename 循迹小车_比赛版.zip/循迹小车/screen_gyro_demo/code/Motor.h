/*
 * Motor.h
 *
 *  Created on: 2024��10��21��
 *      Author: LS
 */
#include "zf_common_headfile.h"

#ifndef MOTOR_H_
#define MOTOR_H_

#define Left_1        (TIM4_PWM_MAP1_CH1_D12)
#define Left_2        (TIM4_PWM_MAP1_CH2_D13)
#define Right_1       (TIM4_PWM_MAP1_CH3_D14)
#define Right_2       (TIM4_PWM_MAP1_CH4_D15)
void PWM_control(void);
void PWM_control_2(void);
void Motor_control(void);
void Forward(void);
void Backward(void);
void TurnLeft(void);
void TurnRight(void);
void Stop(void);
void Turn_Left(void);
void Turn_Right(void);

#endif /* MOTOR_H_ */
