/*
 * IMU_Train.h
 *
 *  Created on: 2024��10��27��
 *      Author: LS
 */

#ifndef IMU_TRAIN_H_
#define IMU_TRAIN_H_

void MPU_Train(void);

extern float err_ang;
extern float Standard_angle;
extern int angle_0_falg;

#endif /* IMU_TRAIN_H_ */
