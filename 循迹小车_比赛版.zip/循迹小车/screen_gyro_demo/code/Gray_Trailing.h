/*
 * Gray_Trailing.h
 *
 *  Created on: 2024��10��21��
 *      Author: LS
 */

#ifndef GRAY_TRAILING_H_
#define GRAY_TRAILING_H_

uint16_t Sensor_GetState(void);
void gray_check(void);

typedef struct
{
    int Left_Flag;
    int Right_Flag;
    int Stop_Flag;
}My_stop;

extern My_stop my_stop;
#endif /* GRAY_TRAILING_H_ */
