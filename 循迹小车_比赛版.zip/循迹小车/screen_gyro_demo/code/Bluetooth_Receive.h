/*
 * Bluetooth_Receive.h
 *
 *  Created on: 2024��10��24��
 *      Author: LS
 */

#ifndef BLUETOOTH_RECEIVE_H_
#define BLUETOOTH_RECEIVE_H_

void Blue_rx_interrupt_handler (void);
void Blue_rx_interrupt_handler2 (void);
void Blue_control(void);

#endif /* BLUETOOTH_RECEIVE_H_ */
