/*
 * Mpu_6050_Settle.h
 *
 *  Created on: 2024��10��20��
 *      Author: LS
 */

#ifndef MPU_6050_SETTLE_H_
#define MPU_6050_SETTLE_H_
#include "zf_common_headfile.h"

void ACC_GET(void);
float angle_calc(float angle_m, float gyro_m);


#endif /* MPU_6050_SETTLE_H_ */
