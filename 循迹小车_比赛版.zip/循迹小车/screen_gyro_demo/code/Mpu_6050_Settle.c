/*
 * Mpu_6050_Settle.c
 *
 *  Created on: 2024年10月20日
 *      Author: LS
 *      陀螺仪解算——>角度
 *      加速度计结算、融合结算
 */

#include "zf_common_headfile.h"

void ACC_GET(void)//加速度计解算
{
    //Y轴-pitch mpu6050_acc_x
    //X轴-roll
    //弧度转换为角度（乘以 180/PI）
    mpu6050_get_acc();//get到ACC的数据

    Pitch = atan2(mpu6050_acc_y, sqrt(mpu6050_acc_x * mpu6050_acc_x + mpu6050_acc_z * mpu6050_acc_z)) * 180.0 / PI;
    Roll = atan2(-mpu6050_acc_x, mpu6050_acc_z) * 180.0 / PI;

    Pitch = Pitch*1.05; //乘一个系数因子 之后角度就很准了
    Roll = Roll*1.07;
}

//比例因子
float acc_ratio = 1.6;      //加速度计比例
float gyro_ratio = 4.08;    //陀螺仪比例
float dt = 0.01;           //采样周期 10ms

//angle_m-与运行方向相同的轴 加速度
//gyro_m- 平行于水平面的轴 角速度
//融合加速度计和陀螺仪的数据来计算当前的角度
//----------------------------------------------------------------    
//  @brief      一阶互补滤波    
//  @param      angle_m     加速度计数据    
//  @param      gyro_m      陀螺仪数据    
//  @return     float       数据融合后的角度    
//----------------------------------------------------------------   
float angle_calc(float angle_m, float gyro_m)//融合计算当前角度
{
    //不对变量进行初始化的操作的话 值默认为0
    float temp_angle;
    float gyro_now;
    float error_angle;

    static float last_angle;
    static uint8 first_angle = 0;//标志位

    if(!first_angle)//判断是否为第一次运行本函数
    {
        //如果是第一次运行，则将上次角度值设置为与加速度值一致
        first_angle = 1;
        last_angle = angle_m;
    }

    //陀螺仪角速度转换
    gyro_now = gyro_m * gyro_ratio;

    //角度误差计算
    //根据测量到的加速度值转换为角度之后与上次的角度值求偏差
    error_angle = (angle_m - last_angle)*acc_ratio;

    //根据偏差与陀螺仪测量得到的角度值计算当前角度值
    temp_angle = last_angle + (error_angle + gyro_now)*dt;

    //保存当前角度值
    last_angle = temp_angle;

//    if(temp_angle>=180)
//    {
//        temp_angle-=180;
//    }
//    else if(temp_angle<=-180)
//    {
//        temp_angle+=180;
//    }

    return temp_angle;
}


