/*
 * Bluetooth_Receive.c
 *
 *  Created on: 2024��10��24��
 *      Author: LS
 *      �������մ���
 */



#include "zf_common_headfile.h"

unsigned char shujv_b[12];
int blue_I=0;


//������ʮ�����Ƶ���ʽ�շ����ݵ�
//ascii    ʮ���ƣ�DEC��       ʮ�����ƣ�HEX��
//0         48           30
void Blue_rx_interrupt_handler (void)
{

    uint8 dat_b;
    dat_b=uart_read_byte(VOFA_UART_INDEX);
    shujv_b[blue_I]=dat_b;
    blue_I++;

    if(dat_b==0x5A)//֡β�̶�ֵ
    {
        //ң��
//        if(shujv_b[3]==0x5A)//֡ͷ�̶�ֵ
//        {
//            my_dat.forword =  shujv_b[1];
//            my_dat.turn =  shujv_b[2];
//        }
        //��ť
        if(shujv_b[0]==0xA5)//֡ͷ�̶�ֵ
        {
            my_dat.biaozhi_F =  shujv_b[1];
            my_dat.biaozhi_B =  shujv_b[2];
            my_dat.biaozhi_L =  shujv_b[3];
            my_dat.biaozhi_R =  shujv_b[4];
            my_dat.biaozhi_S =  shujv_b[5];

        }
    }
}//Blue_rx_interrupt_handler





void Blue_rx_interrupt_handler2 (void)
{

    uint8 dat_b;
    dat_b=uart_read_byte(VOFA_UART_INDEX);

    if(dat_b=='0')
    {
        my_dat.biaozhi_S = '5';
    }
     else if(dat_b=='5')
    {
        my_dat.biaozhi_S = '5';
    }
    else if(dat_b=='1')
    {
        my_dat.biaozhi_F = '1';
        //VOFA_write_int(1);
    }
    else if(dat_b=='2')
    {
        my_dat.biaozhi_B = '2';
        //VOFA_write_int(2);
    }

    else if(dat_b=='3')
    {
        my_dat.biaozhi_L = '3';
    }

    else if(dat_b=='4')
    {
        my_dat.biaozhi_R = '4';
    }


}//Blue_rx_interrupt_handler














// F��ǰ�� B-���� L-��ת R-��ת S-ֹͣ  ��ֵΪ��ť����ʱ��ֵ
// ���еİ�ť �ɿ�ʱֵ��Ϊ0
void Blue_control(void)
{
    if(my_dat.biaozhi_F=='1'){
        Forward();
        //VOFA_write_int(2);
    }
    else if(my_dat.biaozhi_B=='2'){
        Backward();
    }
    else if(my_dat.biaozhi_L=='3'){
        TurnLeft();
    }
    else if(my_dat.biaozhi_R=='4'){
        TurnRight();
    }
    else if(my_dat.biaozhi_S=='5'){
        Stop();
    }

    //system_delay_ms(100);
    my_dat.biaozhi_S = '0';
    my_dat.biaozhi_F = '0';
    my_dat.biaozhi_L = '0';
    my_dat.biaozhi_R = '0';
    my_dat.biaozhi_B = '0';


}//Blue_control
