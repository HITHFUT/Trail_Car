#include "zf_common_headfile.h"

void PID_init(PIDController *pid)
{
    pid->Kp=-400;
    pid->Ki=-500;
    pid->Kd=0;
    pid->last_err=0;
    pid->integral=0;
}

void PID_init_mpu6050(PIDController *pid)
{
    pid->Kp=0;
    pid->Ki=-400;
    pid->Kd=0;
    pid->last_err=0;
    pid->integral=0;
}

float PID_value(float measure,float calcu,PIDController *pid)
{
    float err;
    err = measure - calcu;  //�������

    pid->integral += err*PID_PIT*0.001; //������ֲ���
//    xianfu(pid->integral,3000);

    float derivative = (err - pid->last_err)/(PID_PIT*0.001);   //����΢�ֲ���
    pid->last_err = err;

    float PID_result = pid->Kp*err+pid->Ki*pid->integral+pid->Kd*derivative;
    return PID_result;
}

//a�����ֵ,b:��Сֵ
void xianfu_int16(int16 * data,int16 a,int16 b)
{
    if(*data > a)
        *data = a;
    if(*data < b)
        *data = b;
}

void xianfu_float(float * data,int16 a,int16 b)
{
    if(*data > a)
        *data = a;
    if(*data < b)
        *data = b;
}

