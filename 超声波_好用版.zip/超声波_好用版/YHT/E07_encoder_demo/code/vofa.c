/***�ൺ������ѧ***
****����һ��****
****������**������**�¹���**
****2023/1/15**
****vofa.c**
*/
#include "zf_common_headfile.h"


unsigned char tail[4] = {0x00, 0x00, 0x80, 0x7f};


/*************************************************************
** Function name:      VOFA ��ʼ��
** Descriptions:       ��ʼ��vofa���ڼ��ж�
** Input parameters:   none
** Output parameters:  none
** Returned value:     none
** Created by:         qkk
** Created date:       22/10/23
*************************************************************/

void VOFA_INIT(void)
{
    uart_init(VOFA_UART_INDEX, VOFA_UART_BAUDRATE, VOFA_UART_TX_PIN, VOFA_UART_RX_PIN);
    uart_rx_interrupt(VOFA_UART_INDEX, ENABLE);                                      // ���� UART_INDEX �Ľ����ж�
    interrupt_set_priority(VOFA_UART_PRIORITY, 0);                                   // ���ö�Ӧ UART_INDEX ���ж����ȼ�Ϊ 0

    my_dat.s        =  1;
    my_dat.p        =  1;
    my_dat.i        =  1;
    my_dat.d        =  1;

    my_dat.A        =  1;
    my_dat.B        =  1;
    my_dat.C        =  1;
    my_dat.D        =  1;
}


/*************************************************************
** Function name:      VOFA ���ͺ���
** Descriptions:       ����һ���ֽ�
** Input parameters:   dat    Ҫ���͵�float
** Output parameters:  none
** Returned value:     none
** Created by:         qkk
** Created date:       22/10/23
*************************************************************/
void VOFA_write_byte(const uint8 dat)
{
    uart_write_byte(VOFA_UART_INDEX, dat);
}
/*************************************************************
** Function name:      VOFA float ���ͺ���
** Descriptions:       ����һ��float
** Input parameters:   dat    Ҫ���͵�float
** Output parameters:  none
** Returned value:     none
** Created by:         qkk
** Created date:       22/10/23
*************************************************************/
void VOFA_write_float( float dat)
{
    FLOAT_BYTE vofa_dat;
    u8 vofa_i;

    vofa_dat.floatData = dat;
    for(vofa_i=0;vofa_i<4;vofa_i++)
    {
        VOFA_write_byte(vofa_dat.byteData[vofa_i]);
    }


}
/*************************************************************
** Function name:      VOFA int ���ͺ���
** Descriptions:       ����һ������
** Input parameters:   dat    Ҫ���͵�����
** Output parameters:  none
** Returned value:     none
** Created by:         qkk
** Created date:       22/10/23
*************************************************************/
void VOFA_write_int( int dat)
{
    FLOAT_BYTE vofa_dat;
    u8 vofa_i;

    vofa_dat.floatData = dat;
    for(vofa_i=0;vofa_i<4;vofa_i++)
    {
        VOFA_write_byte(vofa_dat.byteData[vofa_i]);
    }


}
/*************************************************************
** Function name:      VOFA ֡β ���ͺ���
** Descriptions:       ����һ��֡β
** Input parameters:   dat    Ҫ���͵�֡β
** Output parameters:  none
** Returned value:     none
** Created by:         qkk
** Created date:       22/10/23
*************************************************************/
void Just_end(void)
{
    u8 vofa_i;

    for(vofa_i=0;vofa_i<4;vofa_i++)
    {
        VOFA_write_byte(tail[vofa_i]);
    }
}


/*************************************************************
** Function name:      VOFA �жϴ�������
** Descriptions:       ����vofa����
** Input parameters:   none
** Output parameters:  none
** Returned value:     none
** Created by:         qkk
** Created date:       22/10/23
*************************************************************/
unsigned char shujv[12];
int vofa_i=0,vofa_I=0;
float vofa_float;

MY_VOFA my_dat;


void VOFA_rx_interrupt_handler (void)
{
    uint8 dat;

    uart_read_byte(UART_3, &dat);
    shujv[vofa_I]=dat;
    vofa_I++;

    if(dat==0x0a)
    {

        for(vofa_i=2,vofa_float=0;vofa_i<vofa_I-1;vofa_i++)
        {
//            vofa_float=10*vofa_float+(shujv[vofa_i]-'0');
//            if(shujv[2]==0x2d)
//            {
//                vofa_float=10*vofa_float+(shujv[vofa_i+1]-'0');
//                if(vofa_i==vofa_I-2)
//                {
//                    vofa_float=-(int)(vofa_float/10)-4;
//                    break;
//                }
//            }
//            else
//            {
                vofa_float=10*vofa_float+(shujv[vofa_i]-'0');
//            }
        }
        vofa_I=0;

        if(shujv[1]==0x3A)
        {
            switch(shujv[0])
            {
//                case 'S':my_dat.s =  shujv[2]  ; break;
                case 'p':my_dat.p       =  vofa_float; break;
                case 'i':my_dat.i       =  vofa_float; break;
                case 'd':my_dat.d       =  vofa_float; break;

                case 'A':my_dat.A       =  vofa_float; break;
                case 'B':my_dat.B       =  vofa_float; break;
                case 'C':my_dat.C       =  vofa_float; break;
                case 's':my_dat.s       =  vofa_float; break;
            }
        }
    }
}
