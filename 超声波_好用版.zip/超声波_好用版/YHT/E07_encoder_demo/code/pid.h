#ifndef _PID_H_
#define _PID_H_

#include "zf_common_headfile.h"

//#define PID_KP -300
//#define PID_KI -500
//#define PID_KD 0
#define PID_PIT 10      //measure��Ӧ������Ӧ��ʱ���жϵ��ж�ʱ��

typedef struct {
    float last_err;
    float Kp;
    float Ki;
    float Kd;
    float integral;//����
}PIDController;


void PID_init(PIDController *pid);
float PID_value(float measure,float calcu,PIDController *pid);
void xianfu_int16(int16 * data,int16 a,int16 b);
void xianfu_float(float * data,int16 a,int16 b);

#endif
